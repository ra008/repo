/** 
* author Hetvi Patel
* Purpose of the superclass is to store a subclass of relevent student information.
**/

public class Student {
    private String schoolName;
    private String name;
    private String numCourse;
    private String importantDates;

    // Setter method to take a parameter and assign it to the attribute
    Student (String b, String c, String d, String e) {
        schoolName = b;
        name = c;
        importantDates = d;
        numCourse = e;
    }
    
    //A method to print a statement of the student's information
    public void display2() {
        System.out.println("Your student information is: \n" + schoolName + "\n" + name + "\n" + importantDates +"\n" + numCourse);
    }

}

