/**
* author Hetvi Patel
* Purpose of this subclass is to store relevent information for students - subclass of Student.java
 */
public class StudentInfo extends Student {
    private String schoolInfo;
    private String name;
    private String importantDatesInfo;
    private String numCourseInfo;
    
    StudentInfo(String b, String c, String d, String e) {
        super(b, c, d, e); 
        schoolInfo = b;
        name = c;
        importantDatesInfo = d;
        numCourseInfo = e;
    }

    public void display4() {
       System.out.println("Your student information is:\n" + schoolInfo + "\n" + name + "\n" + importantDatesInfo + "\n" + numCourseInfo);
    }
}
