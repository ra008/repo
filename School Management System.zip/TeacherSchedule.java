/** 
* author Reva Ahlawat
* Purpose of this class is to store a schedule for teachers
**/

public class TeacherSchedule {
    private String sch;

    //Setter method to take in a parameter, and assign it to the attribute
    TeacherSchedule(String h) { 
        sch = h;
    }
    
    //Method to print the teacher's schedule
    public void display5() {
        System.out.println(sch);
    }
    
}

    