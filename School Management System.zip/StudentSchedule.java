/** 
* author Hetvi Patel
* Purpose of this class is to store a schedule for students.
**/
public class StudentSchedule {
    private String sch;
    
    // Setter method to take a parameter and assign it to the attribute
    StudentSchedule(String a) { 
        sch = a;
    }

    //A method to print student's schedule
    public void display3() {
        System.out.println(sch);
    }
}
