/* Pick Your Poison - School Managment System
Purpose: A program that consists of a school management system for teachers and students to access to view their schedule, important information for students, class lists for teachers as well as a directory guide of the school.
By: Hetvi Patel & Reva Ahlawat 
Date: May 30, 2022
Last Modified: June 21, 2022 
*/

import java.io.*;
import java.util.Scanner;
import java.util.*;
import java.io.IOException;
public class Main {
    public static void main(String[] args) throws IOException {
        intro();
    }

    /**
    * @author Hetvi Patel
    * Purpose of the method is to ask user what they want to see based on the options available.
    **/
    public static void intro() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to our School Managment System ッ \nPlease Select an Option: \nA) Student\nB) Teacher\nC) School Directory");
        String options = sc.nextLine();

        if (options.equalsIgnoreCase("a")) { // if option "a" is entered the following methods will run...
            loginInfo();
            studentChoices();
        }
        else if (options.equalsIgnoreCase("b")) { // if option "b" is entered the following methods will run...
            loginInfo();
            teacherChoices();
        } 
        else if (options.equalsIgnoreCase("c")) { // if option "c" is entered the following code will run...
            roomNum();
            department();
        }
    }
    
    /**
    * @author Hetvi Patel 
    * Purpose of the method is to print a menu for students - user chooses an option they want to see.
    **/
    public static void studentChoices() throws IOException  {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please select an option you would like to see:\nA) Student Schedule\nB) Student ID\nC) Logout");
        String options = sc.nextLine();

        if (options.equalsIgnoreCase("a")) { // if option "a" is entered the following methods will run...
            studentSch();
        }
        else if (options.equalsIgnoreCase("b")) { // if option "b" is entered the following methods will run...
            studentInfo();
        }
        else if (options.equalsIgnoreCase("c")) { // if option "c" is entered the following methods will run...
            logout();
        }    
    }

     /**
    * @author Reva Ahlawat
    * Purpose of the method is to print a menu for teachers - user chooses an option they want to see.
    **/
    public static void teacherChoices() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please select an option you would like to see:\nA) Teacher Schedule \nB) Class List\nC) Logout");
        String options = sc.nextLine();

        if (options.equalsIgnoreCase("a")) { // if option "a" is entered the following methods will run...
            teacherSch();
        }
        else if (options.equalsIgnoreCase("b")) { // if option "b" is entered the following methods will run...
            classList();
        }
        else if (options.equalsIgnoreCase("c")) { // if option "c" is entered the following method will run...
            logout();
        } 
    }
    
    /**
    * @author Hetvi Patel
    * Purpose of the method is to print a logout menu when the user wants to quit. 
    **/
    public static void logout() throws IOException {
        Scanner myScan = new Scanner(System.in);

        System.out.print("If you want to log back in, press Y. Or select X to exit: ");
        String options = myScan.nextLine();
        if (options.equalsIgnoreCase("y")) { // if option "a" is entered the following methods will run...
            intro();
        }
        else if (options.equalsIgnoreCase("x")) { // if option "x" is entered the following will be printed
            System.out.println("Goodbye, we hope to see you again ッ");  
        }
    }

    /**
    * @author Reva Ahlawat
    * Purpose of the method is for students/teachers to login.
    **/
    public static void loginInfo() throws IOException {
        Scanner myScan = new Scanner(System.in);
        
        System.out.println("Please enter your username (which is your email in the format of: firstName.lastName@sms.ca): ");
        String userName = myScan.nextLine();
        System.out.println("Enter your registered password: ");
        String userPassword = myScan.nextLine();
    
        FileWriter fwriter1 = new FileWriter("UserName.txt", true); // username will be stored to a textfile (UserName.txt)
        PrintWriter storeUserName = new PrintWriter(fwriter1);
        storeUserName.print(userName + "\n");
        storeUserName.close();
        
        FileWriter fwriter2 = new FileWriter("UserPassword.txt", true); // password will be stored to a textfile (UserPassword.txt)
        PrintWriter storePassword = new PrintWriter(fwriter2);
        storePassword.print(userPassword + "\n");
        storePassword.close();
    } 

    /**
    * @author Hetvi Patel
    * Purpose of the method is to ask the user for their full name.
    * @param n A string to be passed to other methods.
    **/
    public static void userName(String n) {
        System.out.println(n + ", here is your full year schedule below! If you need to make any changes with your courses, see guidance ASAP before the start of your semester!\n");
    }
    
    /**
    * @author Hetvi Patel
    * Purpose of the method is to print a schedule for students.
    **/
    public static void studentSch() throws IOException {
        Scanner scannerOne = new Scanner(System.in);
        System.out.print("\n");
        System.out.print("Please enter your full name: ");
        String name = scannerOne.nextLine();
        userName(name);

        // create arraylist to store the list of courses from the textfile
        Scanner scannerTwo = new Scanner(new File("CourseList.txt"));  
        ArrayList <String> courses = new ArrayList <String> (); 
        while (scannerTwo.hasNextLine()) {
            courses.add(scannerTwo.nextLine());
        }
 
        // Store the course time (textfile) of the course into an ArrayList
        Scanner myScan = new Scanner(new File("CourseTime.txt")); 
        ArrayList <String> time = new ArrayList<String>(); 
        while (myScan.hasNextLine()) {
            time.add(myScan.nextLine());
        }
 
        // Generate 8 random numbers between 0 to 16 since there are 16 elements in the ArrayList - using those numbers the corresponding course will be printed out to the user
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
 
        ArrayList <Integer> numbers = new ArrayList <Integer>(); // Creates a new ArrayList with numbers 0 to 16 which will be used to generate random numbers from this list
        for (int n = 0; n < 17; n++) {
        numbers.add(n);
        }

        System.out.println("Your schedule for semester 1 is: ");
        int getTime = 0; //Variable which will be used to print the course start and end time 
        
        for (int q = 0; q < 2; q++) { // For-loop that generates 5 numbers between 0 to 16 and based on the number, prints a course 
            int randNum = random.nextInt(numbers.size());  // Generates a random number from the ArrayList numbers
            StudentSchedule st1 = new StudentSchedule(courses.get(randNum) + " | " + time.get(getTime));
            st1.display3();
            getTime++;
            numbers.remove(randNum); // Removes the number so that the same number will not be generated again
            courses.remove(randNum); // Removes the course so that the same course will not be outputted again
        } // end the loop after printing the morning courses because next is lunch

        System.out.println("Lunch | 11:35 am - 12:15 pm");
        getTime = 2; // sets to 2 because 2 out of 4 courses are left to be outputted

        for (int x = 0; x < 2; x++) { //repeats the same steps as done above
            int randNum = random.nextInt(numbers.size());  
            StudentSchedule st2 = new StudentSchedule(courses.get(randNum) + " | " + time.get(getTime));
            st2.display3();

            getTime = getTime + 1;
            numbers.remove(randNum); 
            courses.remove(randNum);
        } 

        System.out.println("\nYour schedule for semester 2 is: ");
        getTime = 0;
        
        for (int q = 0; q < 2; q++) { // For-loop that generates 5 numbers between 0 to 19
            int randNum = random.nextInt(numbers.size());  // Generates a random number from the ArrayList numbers

            StudentSchedule st3 = new StudentSchedule(courses.get(randNum) + " | " + time.get(getTime));
            st3.display3();

            getTime = getTime + 1;
            numbers.remove(randNum); // Removes the number so that the same number will not be generated again
            courses.remove(randNum); // Removes the course so that the same course will not be generated again
        } 

        System.out.println("Lunch | 11:35 am - 12:15 pm");
        getTime = 2; //Sets to 2 since 2 out 4 more courses are left to be outputted

        //Repeats the steps above
        for (int x = 0; x < 2; x++) { 
            int randNum = random.nextInt(numbers.size());  
            StudentSchedule st4 = new StudentSchedule(courses.get(randNum) + " | " + time.get(getTime));
            st4.display3();
            
            getTime = getTime + 1;
            numbers.remove(randNum); 
            courses.remove(randNum); 
        } 
        System.out.print("\n");
        studentChoices();
    }

    /**
    * @author Reva Ahlawat
    * Purpose of the method is to print relevent student information 
    **/
    public static void studentInfo() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter your name: ");
        String userName = sc.nextLine();

        FileWriter fwriter2 = new FileWriter("ClassList.txt", true); //creates a file to store user's inputted name
        PrintWriter storeName = new PrintWriter(fwriter2);
        storeName.print(userName + "\n");
        storeName.close();

        StudentInfo stuInfo = new StudentInfo("\nSchool Name: York Memorial C.I.\n", "Name: " + userName, "\nImportant Dates:\nFirst day of School is September 7\nParent Teacher Meeting for Semester 1 is November 24\nParent Teacher Meeting for Semester 2 is April 20\nLast Day of School is June 24\n", "You have 4 courses this semester!\n");
        stuInfo.display4();
        studentChoices();
    }

    /**
    * @author Hetvi Patel
    * Purpose of the method is to return a sum of 2 numbers
    * @param x The first number to be added
    * @param y The second number to be added
    **/
    public static int returnNum(int x, int y) throws IOException {
        int sum = x + y;
        return sum;
    }
    
     /**
    * @author Reva Ahlawat
    * Purpose of the method is to let teachers know what courses the are teaching
    **/
    public static void teacherSch() throws IOException {
        int sum = returnNum(4, 4); 
        System.out.println("You will teach " + sum + " courses this year!");

        Scanner myScan = new Scanner(new File("CourseList.txt")); 
        ArrayList <String> courses = new ArrayList <String> (); //adds all the courses from the CourseLisy file into an arrayList
        while (myScan.hasNextLine()) {
            courses.add(myScan.nextLine());
        }
 
        //Store the course time (textfile) of the course into an ArrayList
        Scanner sc = new Scanner(new File("CourseTime.txt"));
        ArrayList <String> time = new ArrayList<String>(); 
        while (sc.hasNextLine()) {
            time.add(sc.nextLine());
        }
 
        // Generate 8 random numbers between 0 to 16 since there are 16 elemnets in the ArrayList - using those numbers the corresponding course will be printed out to the user
        Scanner scc = new Scanner(System.in);
        Random random = new Random();
 
        ArrayList <Integer> numbers = new ArrayList <Integer>(); // Creates a new ArrayList with numbers 0 to 16 which will be used to generate random numbers from this list
        for (int n = 0; n < 17; n++) {
        numbers.add(n);
        }

        int getTime = 0;
        System.out.println("You will be teaching these courses for semester 1 is: ");
        for (int q = 0; q < 2; q++) { // For-loop that generates 4 numbers between 0 to 16 and based on the number, prints a course 
            int randNum = random.nextInt(numbers.size());  // Generates a random number from the ArrayList numbers
     
            TeacherSchedule ts1 = new TeacherSchedule(courses.get(randNum) + " | " + time.get(getTime));
            ts1.display5();
        
            getTime = getTime + 1;
            numbers.remove(randNum); // Removes the number so that the same number will not be generated again
            courses.remove(randNum); // Removes the course so that the same course will not be outputted again
        } // end the loop after printing the morning courses because next is lunch

        System.out.println("Lunch | 11:35 am - 12:15 pm");
        getTime = 2; // sets to 2 because 2 out of 4 courses are left to be outputted

        for (int x = 0; x < 2; x++) { //repeats the same steps as done above
            int randNum = random.nextInt(numbers.size());  

            TeacherSchedule ts1 = new TeacherSchedule(courses.get(randNum) + " | " + time.get(getTime));
            ts1.display5();

            getTime = getTime + 1;
            numbers.remove(randNum); 
            courses.remove(randNum);
        } 

        System.out.println("\nYou will be teaching these courses for semester 2 is: ");
        getTime = 0;
        
        for (int q = 0; q < 2; q++) { // For-loop that generates 4 numbers between 0 to 16
            int randNum = random.nextInt(numbers.size());  // Generates a random number from the ArrayList numbers
            System.out.println(courses.get(randNum) + " | " + time.get(getTime)); // Based on the number generated a question is asked in the console
            getTime = getTime + 1;
            numbers.remove(randNum); // Removes the number so that the same number will not be generated again
            courses.remove(randNum); // Removes the course so that the same course will not be generated again
        } 

        System.out.println("Lunch | 11:35 am - 12:15 pm");
        getTime = 2; //Sets to 2 since 2 out 4 more courses are left to be outputted

        //Repeats the steps above
        for (int x = 0; x < 2; x++) { 
            int randNum = random.nextInt(numbers.size());  

            TeacherSchedule ts1 = new TeacherSchedule(courses.get(randNum) + " | " + time.get(getTime));
            ts1.display5();
            
            getTime = getTime + 1;
            numbers.remove(randNum); 
            courses.remove(randNum); 
        } 
        System.out.print("\n");
        teacherChoices();
    }

 /**
    * @author Reva Ahlawat
    * Purpose of the method is to return value of 2 numbers added
    * @param x The first number to be added
    * @param y The second number to be added
    **/
    public static int returnNumStu(int x, int y) throws IOException {
        int sum = x + y;
        return sum;
    }

 /**
    * @author Reva Ahlawat
    * Purpose of the method is to let teachers know which students are part of their homeroom class
    **/
    public static void classList() throws IOException {
        int sum = returnNumStu(7, 8);
        System.out.println("\nYou will have " + sum + " students in your homeroom class!");

        Scanner myScan = new Scanner(new File("ClassList.txt"));
        ArrayList <String> className = new ArrayList <String> (); 
        while (myScan.hasNextLine()) {
            className.add(myScan.nextLine());
        }

        Scanner scc = new Scanner(System.in);
        Random random = new Random();
 
        ArrayList <Integer> numbers = new ArrayList <Integer>(); // Creates a new ArrayList with numbers 1 to 15 which will be used to generate random numbers from this list
        for (int n = 0; n < 17; n++) {
        numbers.add(n);
        }
    
        System.out.println(" ");
        int getNames = 0;
        
        System.out.print("Your homeroom class list is: \n");
        for (int x = 0; x < 15; x++) { // For-loop that generates 15 numbers between 0 to 50 and based on the number, prints a student name 
            int randNum = random.nextInt(numbers.size());  // Generates a random number from the ArrayList numbers
        
            ClassList cl = new ClassList(className.get(randNum)); // Based on the number generated a name is selected
            cl.display6();
            getNames = getNames + 1;
            numbers.remove(randNum); // Removes the number so that the same number will not be generated again
            className.remove(randNum); // Removes the name so that the same name will not be outputted again
        }
        System.out.print("\n");
        teacherChoices();
    }

 /**
    * @author Reva Ahlawat
    * Purpose of the method is to have a 2D array that stores the course name with their corresponding class room number - a guide for teachers/students to follow 
    **/
    public static void roomNum() throws IOException {
        // A 2D array initialization
        String [][] num2D = {{"English", "Calculus", "Computer Science", "Chemistry", "Kinesiology", "Physics", "French", "Biology", "Data Management", "Cardio", "Families in Canada", "History", "Advanced Functions", "International Business", "Accounting", "Health Science", "Applied Design"}, {"101", "201", "202", "203", "204", "102", "103", "206", "104", "105", "106", "107", "207", "208", "209", "108", "210"}};

        System.out.print("Please refer to the room number for these courses!\n");
        // while loop to go through the strings from the 2D array and print each course with its home room number to the console 
        int i = 0;
        while (i < num2D[0].length) {
            System.out.print(num2D[0][i] + " in Room " + num2D[1][i] + "\n");
            i++;
        }
        System.out.print("\n");
    }

    /**
    * @author Hetvi Patel
    * Purpose of the method is have a 2D array that stores the department names in the school and what courses are within the department
    **/
    public static void department() throws IOException {
         String [][] num2D = {{"Language Department", "Mathematics Department", "Science Department", "Physical Education Department", "Social Science/History Department", "Business Department", "Art Department"}, {"English, French", "Calculus, Data Management, Advanced Functions", "Computer Science, Chemistry, Kinesiology, Physics, Biology, Health Science", "Cardio", "Families in Canada, History", "International Business, Accounting", "Applied Design"}};

        // while loop to go through the strings from the 2D array and print each course with its home room number to the console 
        System.out.println("The school's academic courses are organized into divisions. Here is a list of our departments:");
        int i = 0;
        while (i < num2D[0].length) {
            System.out.print(num2D[0][i] + " 🠮 " + num2D[1][i] + "\n");
            i++;
        }
        System.out.print("\n");
        intro();
    }
    
}