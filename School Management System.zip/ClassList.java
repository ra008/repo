/** 
* author Reva Ahlawat
* Purpose of the subclass is to store student names which are part of the teacher's homeroom class - subclass of Teacher.java
**/

public class ClassList extends Teacher {
    private String classList;

    ClassList(String i) {
        super(i); 
        classList = i;
    }

    public void display6() {
        super.display();
    }
}
