/** 
* author Reva Ahlawat
* Purpose of the superclass is to store a subclass of their homeroom class list. 
**/

public class Teacher {
    private String classList;

     //Setter method to take in a parameter, and assign it to the attribute
    Teacher(String f) {
       classList = f;
    }

    //A method to print a teacher's classlist 
    public void display() {
        System.out.println(classList);
    }

}