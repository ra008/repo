/* Trivia Game Project
By: Hetvi Patel & Reva Ahlawat 
Date: April 8, 2022
Last Modified: May 2, 2022 
*/

import java.io.*;
import java.util.*;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import java.util.Map;
import java.util.stream.Collectors;
import static java.util.stream.Collectors.*;

 
public class Main {
 
public static void main(String[] args) throws IOException { 
    System.out.println("Hello! Welcome to our Trivia Game :) We hope you have a fun time playing this game. The instructions of the game is that there will be 5 random trivia questions asked and the user must give the correct answer with correct spelling. Each correct answer is worth 1 point and your final score will be displayed at the end of the game. Good Luck!\n");

    gameMenu(); 

}

/**
* @author Hetvi Patel
* Purpose of the method is to print a game menu for the user.
**/
public static void userName() throws IOException {
    Scanner sc = new Scanner(System.in);

    System.out.print("Enter your name: ");
    String name = sc.nextLine();

    FileWriter fwriter = new FileWriter("TopScores.txt", true);
    PrintWriter existingFile = new PrintWriter(fwriter);
    existingFile.print(name);
    existingFile.close();

}

/**
* @author Reva Ahlawat
* Purpose of the method is to print a game menu for the user.
**/
public static void gameMenu() throws IOException {
    Scanner sc = new Scanner(System.in);
 
    System.out.println("Please Select An Option: \nA) Start Game \nB) Show Top Scores \nC) Exit Game");
    String options = sc.nextLine();

    if (options.equals("a")) { // if option "a" is entered the following methods will run and the game will start
        userName();
        playerOptionA();
        generateNum(null);
    }
    else if (options.equals("b")) { // if option "b" is entered top 10 scores will be printed to the console
        sortScores();
    }  
    else if (options.equals("c")) { // if option "c" is entered the game will exit 
        playerOptionC();
    }
}
    
/**
* @author Hetvi Patel
* Purpose of the method is make two textfiles to store the questions to one textfile and their answers to another textfile.
**/
public static void playerOptionA() throws IOException {
 
    // New textfile to store the questions that will be asked to the user
    PrintWriter outputQuestions = new PrintWriter("TriviaQuestions.txt"); 
    // Writes to TriviaQuestions.txt
    outputQuestions.println("What is the largest continent?: "); //Russia
    outputQuestions.println("What is the largest river in Africa?: "); //Nile river
    outputQuestions.println("There are 4 timezones in Canada (True or false): "); //False, there are 6
    outputQuestions.println("What is the name of the river that flows through the Brazil rainforest?: "); //Amazon River
    outputQuestions.println("What is the capital city of Australia?: "); //Canberra
    outputQuestions.println("The Statue of Liberty was a gift from France. (Truse or False): "); //True
    outputQuestions.println("What is the flattest continent?: "); //Australia 
    outputQuestions.println("Where is the Suez Canal located?: "); //Egypt
    outputQuestions.println("The island of Maldives is in the continent of Asia. (Truse or False): "); //True
    outputQuestions.println("What is the capital city of the Netherlands: "); //Amsterdam
    outputQuestions.println("How many countries are in the United Kingdom? (Please enter a number): "); //4
    outputQuestions.println("Madagascar is the largest island in Africa. (Truse or False): "); //True
    outputQuestions.println("What is the largest island in the world that is not a continent?: "); //Greenland
    outputQuestions.println("Switzerland has four national languages, English being one of them. (True or False): "); //False, offical languages are German, French, Italian, and Romansh
    outputQuestions.println("What is the capital city of New Zealand?: "); //Wellington
    outputQuestions.println("The official currency of Switzerland is Euros. (Truse or False): "); //False, currency is Swiss franc
    outputQuestions.println("How many pronvinces are there in Canada? (Please enter a number): "); //10
    outputQuestions.println("Which country has the highest population: "); //China
    outputQuestions.println("In which country would you find the Leaning Tower of Pisa?: "); //Italy
    outputQuestions.println("Which country did USA purchase Alaska from?: "); //Russia
    outputQuestions.close();
 
    // New textfile to store the answers to the questions
    PrintWriter outputAnswers = new PrintWriter("TriviaAnswers.txt");
    // Writes to TriviaAnswers.txt
    outputAnswers.println("Russia");
    outputAnswers.println("Nile river");
    outputAnswers.println("False");
    outputAnswers.println("Amazon River");
    outputAnswers.println("Canberra");
    outputAnswers.println("True");
    outputAnswers.println("Australia");
    outputAnswers.println("Egypt");
    outputAnswers.println("True");
    outputAnswers.println("Amsterdam");
    outputAnswers.println("4");
    outputAnswers.println("True");
    outputAnswers.println("Greenland");
    outputAnswers.println("False");
    outputAnswers.println("Wellington");
    outputAnswers.println("False");
    outputAnswers.println("10");
    outputAnswers.println("China");
    outputAnswers.println("Italy");
    outputAnswers.print("Russia");
    outputAnswers.close();
}
 
/**
* @author Reva Ahlawat
* Purpose of the method is to store the textfiles (trivia questions and answers) into ArrayLists and then generate 5 random numbers between 0-19 which will represent the indexes of those questions.
* @param questionsAnsArray A string to be passed to this method.
**/
public static void generateNum (String quesAnsArray) throws IOException {
    playerOptionA();
        
    //Store the Trivia questions (textfile) into an ArrayList
    Scanner myScan = new Scanner(new File("TriviaQuestions.txt"));
    ArrayList <String> questions = new ArrayList <String> (); 
    while (myScan.hasNextLine()) {
        questions.add(myScan.nextLine());
    }
 
    //Store the Trivia answers (textfile) of the questions into an ArrayList
    Scanner sc = new Scanner(new File("TriviaAnswers.txt"));
    ArrayList <String> answers = new ArrayList<String>(); 
    while (sc.hasNextLine()) {
        answers.add(sc.nextLine());
    }
 
    // Generate 5 random numbers between 0 to 19 since there are 19 elemnets in the ArrayList - using those numbers the corresponding question will be printed out to the user for them to answer 
    Scanner scc = new Scanner(System.in);
    Random random = new Random();
 
    ArrayList <Integer> numbers = new ArrayList <Integer>(); // Creates a new ArrayList with numbers 1 to 20 which will be used to generate random numbers from this list
    for (int n = 0; n < 19; n++) {
        numbers.add(n);
    }

    int userScore = 0;  // Sets a new variable to 0 to keep track of player score - 0 is the defult score before a user starts to play the game
 
    for (int q = 0; q < 5; q++) { // For-loop that generates 5 numbers between 0 to 19
        int randNum = random.nextInt(numbers.size());  // Generates a random number from the ArrayList numbers
        System.out.print(questions.get(randNum)); // Based on the number generated a question is asked in the console
        String userAns = scc.nextLine(); 
        numbers.remove(randNum); // Removes the number so that the same number will not be generated again
        questions.remove(randNum); // Removes the question so that the same question will not be asked again
            for (int a = 0; a < 1; a++) { 
                if (userAns.equalsIgnoreCase(answers.get(randNum))) { // Based on the question asked, the answer is read from Answers (arraylist) to check if the player's answer is right 
                System.out.println("That's Correct! You get 1 point :)\n"); 
                answers.remove(randNum);
                userScore++; 
            }
            else if (!userAns.equalsIgnoreCase(answers.get(randNum))) {
                System.out.println("That's Wrong! The right answer is: " + answers.get(randNum) + "\n");
                answers.remove(randNum);
            }
        }
    }
    
    //Appending scores to the TopScores file
    FileWriter fwriter = new FileWriter("TopScores.txt", true);
    PrintWriter existingFile = new PrintWriter(fwriter);
    existingFile.println(": " + userScore);
    existingFile.close();

    printUserScore(userScore);
}

/**
* @author Hetvi Patel
* Purpose of the method is to put TopScore file contents into a HashMap and then sort scores from highest to lowest and display it to the console when asked for.
**/
public static void sortScores() throws IOException {
    // Read TopScores text file to a HashMap
    HashMap <String, Integer> playerScore = new HashMap <String, Integer> ();
    // Iterate over HashMap entries
    for (Map.Entry<String, Integer> entry : playerScore.entrySet()) {
        System.out.println(entry.getKey() + " => " + entry.getValue());
    }

    HashMap <String, Integer> fileContents = new HashMap <String, Integer>();
    BufferedReader br = null;

    File existingFile = new File("TopScores.txt");

    // Create BufferedReader object from the File
    br = new BufferedReader(new FileReader(existingFile));
            
    String line = null; //creates a new string "line" set to null
            
    //read file line by line
    while ((line = br.readLine()) != null){ 
        String[] parts = line.split(":"); // Split the line by ":"
        String name = parts[0].trim(); // First part is name
        Integer score = Integer.parseInt(parts[1].trim()); // Second part is score
        fileContents.put(name, score); // Add name and score to the HashMap
    }

    fileContents.entrySet().stream() .sorted(Map.Entry.<String, Integer> comparingByValue()). forEach(System.out::println); //Collects the sorted entries in Map
    Map<String, Integer> sortedByScore = fileContents.entrySet().stream() .sorted(Map.Entry.<String, Integer> comparingByValue()) .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));

    Map<String, Integer> sortedByValueDesc = fileContents .entrySet() .stream() .sorted(Map.Entry.<String, Integer> comparingByValue().reversed()) .collect( toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

    System.out.println("Top 10 scores of previous players, from highest scores to lowest scores are: " + sortedByValueDesc);

    playAgain(); // Asks the user if they would like to see the main menu again
}

/**
* @author Reva Ahlawat
* Purpose of the method is to print the total score of the user.
* @param userScore The score the user got at the end of the trivia game.
**/
public static void printUserScore (int userScore) throws IOException {
    System.out.println("Good job! You finished the Trivia Game, we hope you had fun :) Your total score for this round is " + userScore + "/5.\n");
 
    playAgain();       

}
 
/**
* @author Reva Ahlawat
* Purpose of the method is to ask user if they want to play the game again.
**/
public static void playAgain() throws IOException {
    Scanner myScan = new Scanner(System.in);
        
    System.out.print("Would you like to see the game menu? (Enter yes or no): ");
    String userPlayAgain = myScan.nextLine();
 
    if (userPlayAgain.equalsIgnoreCase("yes")) {
        gameMenu(); // Calls the gameMenu method - shows the options of the main menu
    }
    if (userPlayAgain.equalsIgnoreCase("no")) {
        System.out.println("Goodbye, we hope to see you again :)");
    }
}
 
/**
* @author Hetvi Patel
* Purpose of the method is to exit the game if the user enters "c" after seeing the game menu.
**/
public static void playerOptionC() throws IOException {
    System.out.println("Goodbye, we hope to see you again :)");          
}  
 
}